﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleMovement : MonoBehaviour {

    public int wallsHit = 1;
    public float speed;
    public GameObject refPlayer;

    private PlayerController pc;

	// Use this for initialization
	void Start () {
        pc = refPlayer.GetComponent<PlayerController>();
	}

    // Update is called once per frame
    void Update() {
        if (wallsHit % 2 == 1)
        {
            transform.position += (transform.forward * speed) * Time.deltaTime;
        }
        else
        {
            transform.position += (-transform.forward * speed) * Time.deltaTime;
        }
	}

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Walls"))
        {
            wallsHit++;
        }
        if (collision.gameObject.CompareTag("Player"))
        {
            //Subtract one from the player's score BY adding to the badObstacleHit accumulator
            pc.badObstacleHit++;
            pc.SetCountText();
        }
    }
}
