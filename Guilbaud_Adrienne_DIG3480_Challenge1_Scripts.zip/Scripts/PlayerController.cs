﻿using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public Transform TransitionPoint;

    public float speed;
    public Text scoreText;
    public Text winText;
    public Text finishText;
    public Text redText;
    public Text yellowText;

    private bool OnStageTwo = false;
    private Rigidbody rb;
    public int score, yellowCount, redCount, badObstacleHit = 0;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        score = 0;
        SetCountText();
        winText.text = "";
        finishText.text = "";
    }

    // Update is called once per frame

    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);

        rb.AddForce(movement * speed);

        if (Input.GetKey("escape"))
            Application.Quit();
    }

    void OnTriggerEnter(Collider other)
    {
        if ((other.gameObject.CompareTag("Pick Up Group 1")) || (other.gameObject.CompareTag("Pick Up Group 2")))
        {
            other.gameObject.SetActive(false);
            yellowCount = yellowCount + 1;
            SetCountText();
        }

        else if (other.gameObject.CompareTag("Bad Pick Up"))
        { 
            other.gameObject.SetActive(false);
            redCount = redCount + 1;
            SetCountText();
        }

        if (((GameObject.FindWithTag("Pick Up Group 1")) == null) && (OnStageTwo == false))
        {
            Debug.Log("On to level two!");
            OnStageTwo = true;
            gameObject.transform.position = TransitionPoint.position;
        }
    }

    public void SetCountText ()
    {
        score = yellowCount - redCount - badObstacleHit; 
        scoreText.text = "Score: " + score.ToString();
        redText.text = "Bad Pick Up Count: " + redCount.ToString();
        yellowText.text = "Pick Up Count: " + yellowCount.ToString();
        if (GameObject.FindWithTag("Pick Up Group 2") == null)
        {
            winText.text = "You Win!";
            finishText.text = "You Finished with a score of: " + score.ToString();
        }
    }
}